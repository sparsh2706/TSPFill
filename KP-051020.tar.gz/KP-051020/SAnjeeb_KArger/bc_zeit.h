#ifndef _BC_ZEIT
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
double CCutil_zeit (void);
#endif
