#include "eg_ddomino.h"

#include "eg_timer.h"
#include "eg_menger_app.h"

#ifndef _EGDDOMAPP
#define _EGDDOMAPP

int EGddominoTest (char *file_name);

#endif
