#include "eg_nettype.h"

void EGfreeNetDdomMP (void *v,
											EGmemPool_t * mem)
{

	int i;

	EGnetDdom_t *ndom;
	ndom = (EGnetDdom_t *) (v);

	for (i = 0; i < 3; i++)
		EGmemPoolFree (ndom->path[i], sizeof (unsigned int) * (ndom->npath[i]),
									 mem);

	EGmemPoolFree (ndom->path, sizeof (unsigned int *) * 3, mem);
	EGmemPoolFree (ndom->npath, sizeof (unsigned int) * 3, mem);

	return;

}
