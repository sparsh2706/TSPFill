#ifndef __EG_1PCHECKER_H__
#define __EG_1PCHECKER_H__
#include <stdlib.h>
#include <stdio.h>
#include "eg_mempool.h"

/* this function check a 2-Pie constraint, and return its violation (negative if
 * it is not violated) and the coefficient of each edge in each constraint in
 * the double array e_coeff (that should have been alocated before calling this
 * function */
int EG1pChecker (int const nnodes,
								 int const nedges,
								 int const *const edges,
								 double const *const weight,
								 int const n_ineq,
								 int const *const n_dom,
								 int *const *const n_Aset,
								 int *const *const n_Bset,
								 int const *const n_handle,
								 int **const *const Aset,
								 int **const *const Bset,
								 int *const *const handle,
								 double *const violation,
								 int *const *const e_coeff);

#endif
