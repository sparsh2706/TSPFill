#ifndef __EG_NETTYPES_H__
#define __EG_NETTYPES_H__

#include<stdio.h>
#include "eg_nettype.h"
#include "eg_mempool.h"

typedef struct
{
	unsigned int s;
	unsigned int t;
	double value;
	unsigned int *npath;
	unsigned int **path;
}
EGnetDdom_t;

void EGfreeNetDdomMP (void *v,
											EGmemPool_t * mem);

#endif
