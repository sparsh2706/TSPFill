#ifndef _GREEDYSAMPLE
#define _GREEDYSAMPLE

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#include "eg_greedytypes.h"
#include "eg_greedykp.h"
#include "eg_kppairs.h"

int EGgenerateRandomInternalPairs( EGgreedyData_t *const gdata,
                                   EGlist_t *const new_pairs,
                                   EGlist_t *const old_pairs,
																	 unsigned int max_new_pairs,
                                   double sample_time );
 
EGinternalPairs_t* EGnewRandomInternalPairs( EGinternalPairs_t *old_pair,
                                             EGlist_t *ext_path,
                                             EGdijkstraCost_t ext_value,
                                             EGmemPool_t *mem );

int EGgreedySample( EGdGraphNode_t *s,
                    EGdGraphNode_t *t,
                    EGdijkstraCost_t st_ubound, 
                    int st_parity,
                    EGgreedyData_t *gdata,
                    EGdijkstraCost_t *path_val,
                    EGlist_t *path );

EGdGraphEdge_t* EGgreedySampleEdge(EGdGraphNode_t *s, 
                                   EGdGraphNode_t *t, 
                                   EGdijkstraCost_t st_ubound,
                                   int st_parity,
                                   EGgreedyData_t *gdata);


int EGaddIPtoList(EGinternalPairs_t *p, EGlist_t *pairs, unsigned int max_size);
EGlist_t* EGmergeIPlists(EGlist_t *first, EGlist_t *second);

#endif
