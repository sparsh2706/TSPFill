#ifndef _DPSEPARATOR
#define _DPSEPARATOR


int DPseparator (int nNodes,
								 int nEdges,
								 int *const edges,
								 double *const origWeight,
								 int *const nIneq,
								 int **const nDominoes,
								 int ***const nAset,
								 int ***const nBset,
								 int **const nHandle,
								 int ****const Aset,
								 int ****const Bset,
								 int ***const Handle,
								 const char *const boss_name,
								 double percentage,
								 double ddp_heuristic_maxtime);

#endif
