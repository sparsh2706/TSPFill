#ifndef __EG_EMPTY_HA
#define __EG_EMPTY_HA

#include <stdio.h>
#include <stdlib.h>

#include "eg_mempool.h"

int DPremoveEmptyHandles (int *const nIneq,
													int **const ndominoes,
													int ***const naset,
													int ***const nbset,
													int **const nhandle,
													int ****const aset,
													int ****const bset,
													int ***const handle);

#endif
