#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifdef LINUX
#include <getopt.h>							/* On linux machines, include this line */
#endif

#include <sys/resource.h>

#include "eg_mempool.h"
#include "eg_heap.h"
